/**
 	* Main AngularJS Web Application
*/
var app = angular.module('mainApp', [
  	'ngRoute',
  	'siteApp',
]);

app.config(['$routeProvider','$locationProvider', function ($routeProvider,$locationProvider) {
  	consolee.log('inside main');
  	$routeProvider.otherwise("/");
  	//$locationProvider.html5Mode(true);
  	
  	$routeProvider.when("/musicLibrary", {
        	templateUrl: "templates/site/partials/musicLibrary/musicLibrary.html"
        });
}]);