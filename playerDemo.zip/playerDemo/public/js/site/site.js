/**
 * Main AngularJS Web Application
 */
var app = angular.module('siteApp', [
    'ngRoute',
    'ngCookies',
    'ngResource',
    'ngStorage',
    'siteMusicLibrary',
    'ngFileUpload',
    'angularUtils.directives.dirPagination',
    'angular-loading-bar',
    'ngSanitize'
]);




app.config(['$routeProvider', '$locationProvider', '$httpProvider', function($routeProvider, $locationProvider, $httpProvider /*, reCAPTCHAProvider*/ ) {

    $routeProvider.otherwise("/");
    $locationProvider.html5Mode(true);

    /*---------------------------------*/
    $httpProvider.interceptors.push(['$q', '$cookieStore',
        function($q, $cookieStore) {
            return {
                request: function(config) {
                    config.headers = config.headers || {};
                    return config;
                },
                response: function(res) {
                    if (res.status === 401) {
                        // Handle unauthenticated user.
                    }
                    return res || $q.when(res);
                }
            };
        }
    ]);
    /*---------------------------------*/


}]).run(function($http, $cookieStore, $localStorage, $interval, $location ,$rootScope) {
        
    
    /* Device and Browser compatibility notification [START]*/

    /* Deletect device name */
    var isMobile = {
        Android: function() {
            return navigator.userAgent.match(/Android/i);
        },
        BlackBerry: function() {
            return navigator.userAgent.match(/BlackBerry|BB10/i);
        },
        iOS: function() {
            return navigator.userAgent.match(/iPhone|iPad|iPod/i);
        },
        Opera: function() {
            return navigator.userAgent.match(/Opera Mini/i);
        },
        Windows: function() {
            return navigator.userAgent.match(/IEMobile/i);
        },
        any: function() {
            return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows());
        }
    };
    var mobileDevice = isMobile.any();

    /* Deletect Browser name */
    navigator.sayswho = (function() {
        var ua = navigator.userAgent,
            tem,
            M = ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];

        if (/trident/i.test(M[1])) {
            tem = /\brv[ :]+(\d+)/g.exec(ua) || [];
            return 'IE ' + (tem[1] || '');
        }
        if (M[1] === 'Chrome') {
            tem = ua.match(/\b(OPR|Edge)\/(\d+)/);
            if (tem != null) return tem.slice(1).join(' ').replace('OPR', 'Opera');
        }
        M = M[2] ? [M[1], M[2]] : [navigator.appName, navigator.appVersion, '-?'];
        if ((tem = ua.match(/version\/(\d+)/i)) != null) M.splice(1, 1, tem[1]);
        return M.join(' ');
    })();

    if (mobileDevice == 'Android' && navigator.sayswho.match(/Chrome/i)) {
        alert("It is recommended to use Firefox browser to play music properly.");
    }
    /* Device and Browser compatibility notification [END]*/
});