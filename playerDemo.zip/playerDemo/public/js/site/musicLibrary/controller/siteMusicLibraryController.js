'use strict';

//Define App module
var siteMusicLibrary = angular.module("siteMusicLibrary",['ngRoute']);

// siteMusicLibrary.config(['$routeProvider',
//     function($routeProvider) {
        
//         $routeProvider.when("/musicLibrary", {
//         	templateUrl: "templates/site/partials/musicLibrary/musicLibrary.html"
//         });

        
//     }
// ]);

siteMusicLibrary.controller('siteMusicLibraryController', ["$rootScope","$scope","$timeout", "$route", "$location", "$http", "$routeParams", "$filter",
	function($rootScope, $scope, $timeout, $route, $location, $http, $routeParams, $filter) {
		
		console.log('inside siteMusicLibraryController');

		$scope.s3BucketURL 				= 'https://s3.amazonaws.com/ios-app-accompany/1/';

		$scope.responseObject={
							      "AudioFiles": [
							        {
							          "index": 1,
							          "tempo": 40,
							          "file": "40.m4a"
							        },
							        {
							          "index": 2,
							          "tempo": 42,
							          "file": "42.m4a"
							        },
							        {
							          "index": 3,
							          "tempo": 44,
							          "file": "44.m4a"
							        },
							        {
							          "index": 4,
							          "tempo": 46,
							          "file": "46.m4a"
							        },
							        {
							          "index": 5,
							          "tempo": 84,
							          "file": "84.m4a"
							        },
							        {
							          "index": 6,
							          "tempo": 126,
							          "file": "126.m4a"
							        },
							        {
							          "index": 7,
							          "tempo": 132,
							          "file": "132.m4a"
							        },
							        {
							          "index": 8,
							          "tempo": 138,
							          "file": "138.m4a"
							        },
							        {
							          "index": 9,
							          "tempo": 144,
							          "file": "144.m4a"
							        },
							        {
							          "index": 10,
							          "tempo": 152,
							          "file": "152.m4a"
							        },
							        {
							          "index": 11,
							          "tempo": 160,
							          "file": "160.m4a"
							        },
							        {
							          "index": 12,
							          "tempo": 168,
							          "file": "168.m4a"
							        },
							        {
							          "index": 13,
							          "tempo": 176,
							          "file": "176.m4a"
							        },
							        {
							          "index": 14,
							          "tempo": 184,
							          "file": "184.m4a"
							        },
							        {
							          "index": 15,
							          "tempo": 192,
							          "file": "192.m4a"
							        },
							        {
							          "index": 16,
							          "tempo": 200,
							          "file": "200.m4a"
							        },
							        {
							          "index": 17,
							          "tempo": 208,
							          "file": "208.m4a"
							        }
							      ]							    
							}
		$scope.tempoArray=[];
		$scope.getMusicLibrary = function(index){
			
			$scope.selectedTempo = 84;
			$scope.defaultTempo = 84;			
			for(var i = 0; i < $scope.responseObject.AudioFiles.length; i++) {

				if(parseInt($scope.responseObject.AudioFiles[i].tempo) === $scope.selectedTempo) {

					$scope.defaultAudioFileIndex 	= i;
					$scope.defaultAudioFile 		= $scope.responseObject.AudioFiles[i].file
				}
	    	}

	    	$scope.tempoArray = $scope.responseObject;

	    	var defaultMusic = $scope.s3BucketURL + $scope.defaultAudioFile;
	    	playMusic(defaultMusic);
		}

		$scope.getTempoDetailPrev =  function(index){
			index = parseInt(index) + 1;
						
			if(index >= 0 && index < $scope.tempoArray.AudioFiles.length) {
				$scope.defaultTempo 			= ($scope.defaultTempoIndex == index) ? true : false;
				$scope.defaultAudioFile 		= $scope.tempoArray.AudioFiles[index].file;
				$scope.defaultAudioFileIndex 	= $scope.tempoArray.AudioFiles[index].index;
				$scope.selectedTempo 			= $scope.tempoArray.AudioFiles[index].tempo;
				$scope.currentTempoIndex 		= $scope.defaultAudioFileIndex;
			}

			var defaultMusic = $scope.s3BucketURL + $scope.defaultAudioFile;
	    	changeAudio(defaultMusic);
		}

		$scope.getTempoDetailNext = function(index){
			index = parseInt(index) - 1;

			if(index >= 0 && index < $scope.tempoArray.AudioFiles.length) {
				$scope.defaultTempo 			= ($scope.defaultTempoIndex == index-1) ? true : false;
				$scope.defaultAudioFile 		= $scope.tempoArray.AudioFiles[index-1].file;
				$scope.defaultAudioFileIndex 	= $scope.tempoArray.AudioFiles[index-1].index;
				$scope.selectedTempo 			= $scope.tempoArray.AudioFiles[index-1].tempo;
				$scope.currentTempoIndex 		= $scope.defaultAudioFileIndex;
			}

			var defaultMusic = $scope.s3BucketURL + $scope.defaultAudioFile;
	    	changeAudio(defaultMusic);
		}

		function playMusic(musicFile){
			console.log('inside playMusic with file as:',musicFile);
		 		 var mediaElements = document.querySelectorAll('audio'), i, total = mediaElements.length;
		 		 
		 		 var sources = [{ src: musicFile, type: 'audio/mp3' }];
				for (i = 0; i < total; i++) {
					new MediaElementPlayer(mediaElements[i], {
						pluginPath: '../build/',
						success: function (mediaElement, originalNode, instance) {
								console.log('mediaElement',mediaElement);
								console.log('originalNode',originalNode);
								console.log('instance',instance);
								 mediaElement.setSrc(sources);
						   }
					});
				}
		 }

		 function changeAudio(musicFile){
			    var audio = document.getElementById("player3");
			    audio.src = musicFile;
			    audio.load();
			    audio.play();
		 }
		 		
    }

  ]);  
