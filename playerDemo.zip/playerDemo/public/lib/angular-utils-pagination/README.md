# angular-utils-pagination

This repo contains only the release version of the dirPagination module from my
[angularUtils](https://github.com/michaelbromley/angularUtils/tree/master/src/directives/pagination) repo. The sole purpose of this repo is to allow for convenient 
dependency management via Bower, npm and other package managers.

## Documentation

All documentation is also located in the [angularUtils project](https://github.com/michaelbromley/angularUtils/tree/master/src/directives/pagination).

## Issues

Please submit any issues to the [angularUtils issue tracker](https://github.com/michaelbromley/angularUtils/issues), not this one.

## Contribution

If you wish to contribute, then please fork the [angularUtils repo](https://github.com/michaelbromley/angularUtils). This repo contains
the tests and is set up to run Karma for unit testing.

## License 

MIT
