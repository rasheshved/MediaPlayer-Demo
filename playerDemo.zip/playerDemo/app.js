var express = require('express');
var favicon = require('serve-favicon');
var morgan = require('morgan');
var compression = require('compression');
var bodyParser = require('body-parser');
var methodOverride = require('method-override');
var cookieParser = require('cookie-parser');
var errorHandler = require('errorhandler');
var path = require('path');
var session = require('express-session');
var path = require('path');
var expressValidator = require('express-validator');
var http = require('http');
var fs = require('fs-extra');
var app = express();
global.router = express.Router();


app.set('appPath', __dirname + '/public');
app.use(express.static(__dirname + '/public'));
//app.use(favicon(__dirname + '/public/assets/fav'));

app.all('/*', function(req, res, next) {
    res.sendFile(app.get('appPath') + '/index.html');
});

// app.get("/musicLibrary",function(req,res){
//     res.sendFile(__dirname + '/public/templates/site/partials/musicLibrary/musicLibrary.html');
// })


http.createServer(app).listen(7085, function() {
    console.log("Express server listening on port 7085");
});

exports = module.exports = app;